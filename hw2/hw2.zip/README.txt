Compiler: GCC

To compile the project:

for Linux use 
> make 

for Windows use
> mingw32-make 

To compile the default program use 
> make default
This will generate an executable called "default.exe".

To compile the tests use 
> make test 
This will generate an executable called "test.exe".