Compiler: GCC

To compile the project:

for Linux use 
> make 

for Windows use
> mingw32-make 

To compile the default program use 
> make store 
This will generate an executable called "store.exe".

To compile the tests use 
> make test 
This will generate an executable called "test.exe".